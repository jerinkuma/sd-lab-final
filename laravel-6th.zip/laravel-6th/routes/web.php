<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\Auth\VerificationController;
use App\Http\Controllers\Auth\LoginRegisterController;
use App\Http\Controllers\Auth\RegisterController;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Auth\Notifications\VerifyEmail;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\HelpController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\FaqController;

use App\Http\Controllers\OrderLineController;
use App\Http\Controllers\UploadController;

use App\Http\Controllers\AdminController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\ProductController;

use App\Http\Controllers\OrderListController;
use App\Http\Controllers\ProductListController;


use App\Http\Controllers\StripePaymentController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



// Define Custom User Registration & Login Routes
Route::controller(LoginRegisterController::class)->group(function () {

    Route::post('/store', 'store')->name('store');
    Route::get('/login', 'login')->name('login');
    Route::post('/authenticate', 'authenticate')->name('authenticate');
    Route::get('/home', 'home')->name('home');
    Route::post('/logout', 'logout')->name('logout');
});

Route::get('email/verify', [VerificationController::class, 'notice'])->name('verification.notice');
Route::post('email/verification-notification', [VerificationController::class, 'resend'])->middleware('auth', 'throttle:6,1')->name('verification.resend');
Route::get('email/verify/{id}/{hash}', [VerificationController::class, 'verify'])
    ->middleware(['auth', 'signed'])
    ->name('verification.verify');






// Display registration form
Route::get('register', [LoginRegisterController::class, 'register'])->name('register');

// Handle the registration form submission
Route::post('register', [LoginRegisterController::class, 'store'])->name('register.store');

// Routes for password reset functionality
Route::get('forgot-password', [PasswordResetController::class, 'showLinkRequestForm'])->name('password.request');
Route::post('forgot-password', [PasswordResetController::class, 'sendResetLinkEmail'])->name('password.email');
Route::get('password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
Route::post('password/reset', [PasswordResetController::class, 'reset'])->name('password.update');

/*
// for home
Route::post('/category', [CategoryController::class, 'show'])->name('category');
Route::post('/search', [SearchController::class, 'search'])->name('search');
Route::get('/cart', [CartController::class, 'index'])->name('cart');
Route::get('/profile', [ProfileController::class, 'index'])->name('profile');
Route::get('/help', [HelpController::class, 'index'])->name('help');
Route::get('/brands', [BrandController::class, 'index'])->name('brands');
Route::get('/logout', [LoginRegisterController::class, 'logout'])->name('logout');
*/

Route::get('/faq', [FaqController::class, 'index'])->name('faq');

Route::get('/cart', [CartController::class, 'index'])->name('cart');
//Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
Route::get('/help', [HelpController::class, 'index'])->name('help');
Route::get('/brands', [BrandController::class, 'index'])->name('brands');

Route::get('/search', [SearchController::class, 'index'])->name('search');


//for profile


Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
    Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::post('/profile/edit', [ProfileController::class, 'update'])->name('profile.update');
    Route::get('/profile/change-password', [ProfileController::class, 'showChangePasswordForm'])
        ->name('profile.changePassword');
    Route::post('/profile/change-password', [ProfileController::class, 'changePassword'])
        ->name('profile.updatePassword');
});


/*Route::get('/profile/edit', [ProfileController::class, 'edit'])->name('profile.edit');
Route::post('/profile/edit', [ProfileController::class, 'update'])->name('profile.update');
Route::get('/profile/change-password', [ProfileController::class, 'showChangePasswordForm'])
    ->name('profile.changePassword');

Route::post('/profile/change-password', [ProfileController::class, 'changePassword'])
    ->name('profile.updatePassword');
    */



    // For searching
Route::get('/search', [SearchController::class, 'index'])->name('search');





//for admin


Route::get('admin/login', [LoginRegisterController::class, 'adminLogin'])->name('admin.login');
Route::post('admin/login', [LoginRegisterController::class, 'authenticate'])->name('admin.login.submit');

Route::middleware(['auth:admin'])->group(function () {
    Route::get('admin/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
});


Route::delete('admin/customers/{id}', [AdminController::class, 'deleteCustomer'])->name('admin.customer.delete');

Route::post('admin/logout', [AdminController::class, 'logout'])->name('admin.logout');


// OrderLine Route
//Route::get('/orderline', [OrderLineController::class, 'index'])->middleware('auth')->name('orderline');

// Upload Routes


/// Route for the product upload form
Route::get('/admin/product_upload', [UploadController::class, 'showForm'])->name('admin.product_upload.form');

// Route for the product upload submit action
Route::post('/admin/product_upload', [UploadController::class, 'upload'])->name('admin.product_upload.submit');

//catagory


Route::get('/categories', [CategoryController::class, 'index'])->name('categories');



Route::get('/home', [CustomerController::class, 'customerHome'])
    ->middleware(['auth', 'verified'])
    ->name('home');

//cart
Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');


// Route to show the checkout page
Route::get('/checkout', [CheckoutController::class, 'index'])->name('checkout');
// Route to handle the checkout form submission
Route::post('/checkout', [CheckoutController::class, 'process'])->name('checkout.process');
//Route::get('/checkout/confirmation', [CheckoutController::class, 'confirmation'])->name('checkout.confirmation');
// Approve an order
// Route::post('/orderline/approve/{id}', [OrderLineController::class, 'approve'])->name('orderline.approve');

// // Decline an order
// Route::post('/orderline/decline/{id}', [OrderLineController::class, 'decline'])->name('orderline.decline');




Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/update/{productId}', [CartController::class, 'update'])->name('cart.update');
Route::post('/cart/remove/{productId}', [CartController::class, 'remove'])->name('cart.remove');
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
Route::put('/cart/update/{id}', [CartController::class, 'update'])->name('cart.update');
Route::delete('/cart/remove/{id}', [CartController::class, 'remove'])->name('cart.remove');


//checkout



Route::get('/checkout', [CheckoutController::class, 'index'])->name('checkout');
Route::post('/checkout/submit', [CheckoutController::class, 'submit'])->name('checkout.submit');

// // Admin Route to view the order and its lines
// Route::get('/admin/orders/{orderId}/orderlines', [OrderLineController::class, 'show'])->name('admin.orderlines.show');

// // Admin Route to update the status of an individual order line
// Route::post('/admin/orders/{orderId}/orderlines/{orderLineId}/update', [OrderLineController::class, 'update'])->name('admin.orderlines.update');


Route::get('/orderline', [OrderLineController::class, 'index'])->name('orderline');


Route::get('/productlist', [ProductController::class, 'index'])->name('productlistt');


Route::get('/checkout/stripe', [StripePaymentController::class, 'stripe'])->name('stripe.form');
Route::post('/checkout/stripe', [StripePaymentController::class, 'stripePost'])->name('stripe.submit');

//update
Route::middleware(['auth'])->group(function () {
    // Show the profile edit form
    Route::get('/profile/edit', [CustomerController::class, 'edit'])->name('profile.edit');

    // Handle the profile update
    Route::post('/profile/update', [CustomerController::class, 'update'])->name('profile.update');
});

Route::post('/profile/update', [CustomerController::class, 'updateProfile'])->name('profile.update');
//admin profile
Route::get('/admin/profile', [AdminController::class, 'profile'])->name('admin.profile');


// web.php


Route::middleware(['auth:admin'])->group(function () {
    Route::get('/admin/profile', [AdminController::class, 'showProfile'])->name('admin.profile');
});

Route::get('/brands', [BrandController::class, 'index'])->name('brands');
Route::post('/brands/follow', [BrandController::class, 'follow'])->name('brand.follow');


// routes/web.php

Route::get('/category/{category}', [ProductController::class, 'showCategory'])->name('categories');
Route::get('/search', [ProductController::class, 'search'])->name('search');


Route::get('/orderline', [OrderLineController::class, 'index']);


Route::get('/orderlist', [OrderListController::class, 'index'])->name('orderlist');
Route::get('/productlist', [ProductListController::class, 'index'])->name('productlist');



Route::get('/orderlist', [OrderListController::class, 'index'])->name('orderlist');
Route::get('/orderlist/create', [OrderListController::class, 'create'])->name('orderlist.create');
Route::post('/orderlist', [OrderListController::class, 'store'])->name('orderlist.store');
