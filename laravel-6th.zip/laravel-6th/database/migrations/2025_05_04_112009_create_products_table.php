<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
{
    Schema::create('products', function (Blueprint $table) {
        $table->id();
        $table->string('P_id')->unique(); // custom product ID
        $table->string('P_name');
        $table->string('Description')->nullable();
        $table->integer('Price');
        $table->string('P_brand')->nullable(); // or use brand_id if normalized
        $table->string('Category')->nullable();
        $table->string('P_img')->nullable();
        $table->timestamps();
    });
}


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
