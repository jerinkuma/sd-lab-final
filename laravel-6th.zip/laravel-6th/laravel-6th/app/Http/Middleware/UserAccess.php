<?php

// app/Http/Middleware/UserAccess.php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\Customer; // Import the Customer model

class UserAccess
{
    public function handle(Request $request, Closure $next, $role)
    {
        // Ensure the user is logged in and has the 'role' attribute
        $customer = auth()->user();  // Assuming auth is set up for customers

        if (!$customer) {
            return redirect()->route('login');  // Redirect if not logged in
        }

        // Check the customer's role
        if ($role == 'admin' && $customer->role == 'admin') {
            return $next($request);
        }
        if ($role == 'user' && $customer->role == 'user') {
            return $next($request);
        }

        // If the role doesn't match, redirect or abort
        return redirect()->route('home');  // or return abort(403);
    }
}

