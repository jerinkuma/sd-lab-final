<?php

namespace App\Http\Controllers;
use App\Models\Orderline;

use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;

class CheckoutController extends Controller
{
    // Method to display the checkout page
    public function index()
{
    $cart = session('cart', []);
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    return view('checkout.index', compact('cart', 'total'));
}
// app/Http/Controllers/CheckoutController.php

// Handle order submission
public function submit(Request $request)
{
    $request->validate([
        'customer_name' => 'required|string|max:255',
        'customer_email' => 'required|email',
        'payment_method' => 'required|string',
    ]);

    $cart = session('cart', []);
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    

    // Create the order

   $Order= OrderLine::create([
        'customer_name' => Auth::user()->name,          // from logged-in user
        'product_name'  => $item['name'],               // from session cart
        'quantity'      => $item['quantity'],           // from session cart
        'price'         => $item['price'],              // from session cart
        'status'        => 'pending',                   // static value
        // 'total_amount' => $total, 
    ]);
}

    // Clear the cart
    session()->forget('cart');

    // Redirect to status page
    return redirect()->route('order.status', $Order->id);

}



}

