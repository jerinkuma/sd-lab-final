<?php

// In app/Http/Controllers/CustomerController.php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\Models\Customer;


class CustomerController extends Controller
{
    public function customerHome()
    {
        // Fetch all products
        $products = Product::all();

        // Pass products to the customer homepage view
        return view('auth.home', compact('products'));
    }
    /**
     * Show the profile edit form.
     *
     * @return \Illuminate\View\View
     */
    public function edit()
    {
        return view('profile.edit');
    }

    /**
     * Update the customer profile.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
   

public function updateProfile(Request $request)
{
    $user = Auth::user(); // get the currently logged-in customer

    // Validate input
    $request->validate([
        'new_username' => 'required|string|max:255|unique:customers,username,' . $user->id,
        'new_email' => 'required|email|max:255|unique:customers,email,' . $user->id,
        'number' => 'required|numeric|digits_between:10,15',
        'address' => 'required|string|max:255',
    ]);

    // Update values
    $user->username = $request->new_username;
    $user->email = $request->new_email;
    $user->phone = $request->number;
    $user->address = $request->address;
    $user->save();

    return redirect()->back()->with('success', 'Profile updated successfully.');
}

}



