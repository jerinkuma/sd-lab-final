<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class AdminProductController extends Controller
{
    // Show all products
    public function index()
    {
        $products = Product::all();
        return view('admin.show', compact('products')); // updated path
    }

    // Show upload form
    public function create()
    {
        return view('admin.upload'); // update this if your upload form is in 'admin' folder
    }

    // Handle product upload
    public function store(Request $request)
    {
        $product = new Product();
        $product->P_id = $request->P_id;
        $product->P_name = $request->P_name;
        $product->Description = $request->Description;
        $product->Price = $request->Price;
        $product->P_brand = $request->P_brand;
        $product->Category = $request->Category;

        if ($request->hasFile('P_img')) {
            $file = $request->file('P_img');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('pimg'), $filename);
            $product->P_img = $filename;
        }

        $product->save();

        return redirect()->back()->with('success', 'Product uploaded successfully!');
    }

    // Edit product form
    public function edit($id)
    {
        $product = Product::findOrFail($id);
        return view('admin.edit', compact('product')); // updated path
    }

    // Update product
    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        // Validation
        $validatedData = $request->validate([
            'P_id' => 'required|string|unique:products,P_id,' . $product->id,
            'P_name' => 'required|string|max:255',
            'Description' => 'required|string',
            'Price' => 'required|numeric',
            'P_brand' => 'required|string|max:255',
            'Category' => 'required|string|max:255',
            'P_img' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Assign values
        $product->P_id = $request->P_id;
        $product->P_name = $request->P_name;
        $product->Description = $request->Description;
        $product->Price = $request->Price;
        $product->P_brand = $request->P_brand;
        $product->Category = $request->Category;

        // Handle image
        if ($request->hasFile('P_img')) {
            $oldImage = public_path('product_images/' . $product->P_img);
            if (File::exists($oldImage)) {
                File::delete($oldImage);
            }

            $file = $request->file('P_img');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('product_images'), $filename);
            $product->P_img = $filename;
        }

        // Save
        $product->save();

        return redirect()->route('admin.show')->with('success', 'Product updated successfully!');
    }
    // Delete product
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $imagePath = public_path('product_images/' . $product->P_img);

        if (File::exists($imagePath)) 
        File::delete($imagePath);
        $product->delete();

        return redirect()->route('admin.show')->with('success', 'Product deleted successfully!');
    }
}
