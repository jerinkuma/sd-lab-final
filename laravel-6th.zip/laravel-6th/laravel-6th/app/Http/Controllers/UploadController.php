<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class UploadController extends Controller
{
    


public function showForm()
{
    // Return the view for the upload form
    return view('admin.product_upload');
}

public function upload(Request $request)
{
    // Handle the product upload logic
    $validated = $request->validate([
        'P_id' => 'required|unique:products,P_id',
        'P_name' => 'required',
        'Description' => 'nullable',
        'Price' => 'required|integer',
        'P_brand' => 'nullable',
        'Category' => 'nullable',
        'P_img' => 'nullable|image|mimes:jpg,png,jpeg|max:2048'
    ]);

    if ($request->hasFile('P_img')) {
        $imageName = time().'.'.$request->P_img->extension();
        $request->P_img->move(public_path('product_images'), $imageName);
        $validated['P_img'] = $imageName;
    }

    Product::create($validated);

    // Redirect to the product upload form with a success message
    return redirect()->route('admin.product_upload.form')->with('success', 'Product uploaded successfully!');
}


}
