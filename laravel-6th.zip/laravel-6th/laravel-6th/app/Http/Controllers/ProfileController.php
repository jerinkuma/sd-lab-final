<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Customer;

class ProfileController extends Controller
{
    public function show()
    {
        $customer = Auth::user();
        return view('profile.show', compact('customer'));
    }

    public function showChangePasswordForm()
    {
        return view('profile.change_password');
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'old_password' => 'required',
            'new_password' => 'required|min:6|confirmed',
        ]);

        $customer = Auth::user();

        // Check if old password is correct
        if (!Hash::check($request->old_password, $customer->password)) {
            return back()->with('error', 'Old password is incorrect.');
        }

        // Update password
        $customer->password = Hash::make($request->new_password);
        $customer->save();

        return back()->with('success', 'Password changed successfully!');
    }

    // Show the profile update form
    public function edit()
    {
        $customer = Auth::user(); // Get the currently authenticated user
        return view('profile.edit', compact('customer'));
    }

    // Update the profile
    public function update(Request $request)
    {
        // Validate the form input
        $request->validate([
            'username' => 'required|string|max:255|unique:customers,username,' . Auth::id(),
            'email' => 'required|email|unique:customers,email,' . Auth::id(),
            'phone' => 'required|numeric',
            'address' => 'required|string|max:255',
        ]);

        $customer = Auth::user(); // Get the currently authenticated user

        // Update the customer's profile information
        $customer->username = $request->username;
        $customer->email = $request->email;
        $customer->phone = $request->phone;
        $customer->address = $request->address;

        // Save the updated customer details
        $customer->save();

        // Redirect with a success message
        return redirect()->route('profile.show')->with('success', 'Profile updated successfully!');
    }
}
