<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\OrderLine;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    // Method to show the cart page with all items
    public function index()
{
    // Retrieve the cart data from the session
    $cart = session('cart', []);

    // Calculate the total price
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // Pass the cart data to the view
    return view('cart.index', compact('cart', 'total'));
}
public function add(Request $request)
{
    // Get the product details from the request
    $productId = $request->input('pid');
    $productName = $request->input('product_name');
    $productPrice = $request->input('product_price');
    $productImage = $request->input('product_image');
    $quantity = $request->input('quantity', 1);  // Default to 1 if no quantity is provided

    // Store the cart items in the session (or you can use the database)
    $cart = session()->get('cart', []);

    // Check if the product is already in the cart
    if (isset($cart[$productId])) {
        $cart[$productId]['quantity'] += $quantity;  // Increase the quantity if it's already in the cart
    } else {
        // Add the product to the cart if it's not already there
        $cart[$productId] = [
            'name' => $productName,
            'price' => $productPrice,
            'quantity' => $quantity,
            'image' => $productImage,
        ];
    }

    // Update the session with the new cart data
    session()->put('cart', $cart);

    // Redirect back to the same page with the success message
    return redirect()->back()->with('success', 'Product added to cart!');
}

    
    // Method to remove a product from the cart
    public function remove($productId)
    {
        $cart = session('cart', []);

        // Remove the product from the cart if it exists
        if (isset($cart[$productId])) {
            unset($cart[$productId]);
        }

        // Update the session with the modified cart
        session(['cart' => $cart]);

        return redirect()->route('cart.index')->with('success', 'Product removed from cart!');
    }

    // Method to update the quantity of a product in the cart
    public function update(Request $request, $productId)
    {
        $cart = session('cart', []);
        $newQuantity = $request->input('quantity');

        // If the product exists in the cart, update its quantity
        if (isset($cart[$productId])) {
            $cart[$productId]['quantity'] = $newQuantity;
        }

        // Update the session with the modified cart
        session(['cart' => $cart]);

        return redirect()->route('cart.index')->with('success', 'Cart updated!');
    }
    public function checkout(Request $request)
{
    $cart = session()->get('cart', []);
    
    if (empty($cart)) {
        return redirect()->back()->with('error', 'Your cart is empty.');
    }

    foreach ($cart as $item) {
        OrderLine::create([
            'customer_name' => Auth::user()->name,
            'product_name'  => $item['name'],
            'quantity'      => $item['quantity'],
            'price'         => $item['price'],
            'status'        => 'pending',
        ]);
    }

    session()->forget('cart'); // Clear cart after order placed

    return redirect()->route('order.status', ['id' => Auth::user()->id]);
}

    
}
