<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\OrderLine;

class OrderLineController extends Controller
{
    public function index()
    {
        $orders = OrderLine::all();
        return view('admin.orderlist', compact('orders'));
    }

    public function approve($id)
    {
        $order = OrderLine::findOrFail($id);
        $order->status = 'approved';
        $order->save();

        return redirect()->back()->with('success', 'Order approved successfully!');
    }

    public function destroy($id)
    {
        $order = OrderLine::findOrFail($id);
        $order->delete();

        return redirect()->back()->with('success', 'Order deleted successfully!');
    }
    public function status($id)
    {
        // Find the order by ID
        $order = OrderLine::findOrFail($id);

        // Return the view with order details
        return view('order.status', compact('order'));
    }
}

