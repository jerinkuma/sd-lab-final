

<?php $__env->startSection('content'); ?>
<style>
    body { background-color: #f0f2f5; font-family: Arial, sans-serif; }
    .order-table { width: 95%; margin: 5vh auto; background: #fff; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 14px; text-align: center; border-bottom: 1px solid #ddd; }
    th { background-color: #4CAF50; color: white; }
    .btn-action { padding: 6px 12px; border: none; border-radius: 5px; cursor: pointer; color: white; }
    .btn-approve { background-color: #28a745; }
    .btn-delete { background-color: #dc3545; }
</style>

<?php if(session('success')): ?>
    <div class="text-center text-success fw-bold mt-3"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="order-table">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Status</th>
                <th>Actions</th>
            

        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->customer_name); ?></td>
                <td><?php echo e($order->product_name); ?></td>
                <td><?php echo e($order->quantity); ?></td>
                <td><?php echo e($order->price); ?></td>
                <td><?php echo e($order->status); ?></td>
                <td>
                <form action="<?php echo e(route('orderlist.approve', $order->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <button type="submit" class="btn btn-success btn-sm">Approve</button>
                    </form>

                    <form action="<?php echo e(route('orderlist.delete', $order->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-6th (4)\laravel-6th\resources\views/admin/orderlist.blade.php ENDPATH**/ ?>