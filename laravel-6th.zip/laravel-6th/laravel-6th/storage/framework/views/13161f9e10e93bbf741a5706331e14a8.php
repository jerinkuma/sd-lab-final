<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Profile</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: white;
        }

        .container {
            width: 70%;
            /* Set the container width as a percentage of the viewport */
            max-width: 900px;
            /* Optional: Set a maximum width */
            margin: 50px auto;
            padding: 0px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgb(137, 133, 133);
        }


        .profile-header {
            text-align: center;
            padding-top: 20px;
            margin-bottom: 30px;
        }

        .profile-header h1 {
            font-size: 36px;
            font-weight: 700;
            color: #333;
        }

        .profile-content {
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
        }

        .profile-overview,
        .profile-info {
            background: #f9f9f9;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .profile-overview {
            flex: 1;
            max-width: 35%;
            text-align: center;
        }

        .profile-info {
            flex: 2;
            max-width: 65%;
        }

        .profile-pic {
            width: 100px;
            height: 100px;
            background: #ddd;
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 45px;
            color: #666;
            border: 3px solidrgb(242, 244, 246);
        }

        .profile-overview h2 {
            font-size: 24px;
            color: #222;
            margin-bottom: 10px;
        }

        .badge {
            display: inline-block;
            background: #4CAF50;
            color: #fff;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
        }

        .profile-info h3 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
        }

        .profile-info table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }

        .profile-info td {
            padding: 12px 10px;
            vertical-align: top;
            color: #444;
        }

        .label {
            font-weight: 600;
            width: 30%;
            color: #111;
        }

        .actions {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 6px;
            text-decoration: none;
            transition: 0.3s;
        }

        .btn-update {
            background: #007bff;
            color: #fff;
            border: 2px solid #0056b3;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.87);

        }

        .btn-update:hover {
            background: #0056b3;
        }

        .btn-password {
            background: #f44336;
            color: #fff;
            border: 2px solid #c62828;
            box-shadow: 0 4px 12px rgba(241, 39, 25, 0.93);
        }

        .btn-password:hover {
            background: #d32f2f;
        }

        @media (max-width: 768px) {
            .profile-content {
                flex-direction: column;
            }

            .profile-overview,
            .profile-info {
                max-width: 100%;
            }
        }
    </style>
</head>

<body>

    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="profile-header">
            <h1>Welcome!</h1>
        </div>

        <div class="profile-content">
            <!-- Left: Profile Overview -->
            <div class="profile-overview">
                <div class="profile-pic">
                    <i class="fa-solid fa-user"></i>
                </div>
                <h2><?php echo e($customer->username); ?></h2>
                <div class="badge">
                    <i class="fa-solid fa-check-circle"></i> Verified User
                </div>
            </div>

            <!-- Right: Profile Details -->
            <div class="profile-info">
                <h3>Profile Details</h3>
                <table>
                    <tr>
                        <td class="label">Email:</td>
                        <td><?php echo e($customer->email); ?></td>
                    </tr>
                    <tr>
                        <td class="label">Phone:</td>
                        <td><?php echo e($customer->phone); ?></td>
                    </tr>
                    <tr>
                        <td class="label">Address:</td>
                        <td><?php echo e($customer->address); ?></td>
                    </tr>
                </table>

                <div class="actions">
                    <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-update">
                        <i class="fa-solid fa-pen-to-square"></i> Update Profile
                    </a>
                    <a href="<?php echo e(route('profile.changePassword')); ?>" class="btn btn-password">
                        <i class="fa-solid fa-lock"></i> Change Password
                    </a>
                </div>
            </div>
        </div>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\laravel-6th\resources\views/profile/show.blade.php ENDPATH**/ ?>