<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Record</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://kit.fontawesome.com/06d164d474.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>

    <style>
        body {
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .container {
            margin-top: 20px;
        }

        .customer-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .customer-card:hover {
            transform: scale(1.05);
        }

        .customer-card h5 {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .customer-card p {
            font-size: 14px;
            color: #555;
        }

        .delete-btn {
            border: none;
            background: transparent;
            font-size: 18px;
            color: red;
            cursor: pointer;
        }

        .delete-btn:hover {
            color: darkred;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <?php echo $__env->make('admin.nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <h1 class="text-center mb-4">Customer Record</h1>

        <!-- Success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <!-- Customer Grid -->
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4 mb-4">
                    <div class="customer-card p-3">
                        <h5><?php echo e($customer->username); ?></h5>
                        <p>Email: <?php echo e($customer->email); ?></p>
                        <p>Mobile: <?php echo e($customer->phone); ?></p>
                        <p>Address: <?php echo e($customer->address); ?></p>
                        <form method="POST" action="<?php echo e(route('admin.customer.delete', $customer->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center">
                    <p>No customers found</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel-6th (4)\laravel-6th\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>