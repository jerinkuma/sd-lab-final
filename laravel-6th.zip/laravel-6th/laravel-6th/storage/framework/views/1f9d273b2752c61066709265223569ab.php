

<?php $__env->startSection('content'); ?>
<div class="cart-page">
    <h2>Your Cart</h2>

    <?php if(count($cart) > 0): ?>
    <table class="cart-table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <img src="<?php echo e(asset('product_images/'.$item['image'])); ?>" alt="<?php echo e($item['name']); ?>" width="50">
                    <?php echo e($item['name']); ?>

                </td>
                <td><?php echo e(number_format($item['price'], 2)); ?>৳</td>
                <td>
                    <form action="<?php echo e(route('cart.update', $id)); ?>" method="POST" style="display: flex; align-items: center;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <button type="submit" name="quantity" value="<?php echo e($item['quantity'] - 1); ?>" class="btn btn-sm btn-secondary" <?php echo e($item['quantity'] <= 1 ? 'disabled' : ''); ?>>-</button>
                        <input type="text" value="<?php echo e($item['quantity']); ?>" readonly style="width: 40px; text-align: center; border: none;">
                        <button type="submit" name="quantity" value="<?php echo e($item['quantity'] + 1); ?>" class="btn btn-sm btn-secondary">+</button>
                    </form>
                </td>
                <td><?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?>৳</td>
                <td>
                    <form action="<?php echo e(route('cart.remove', $id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    <div class="cart-total">
        <h3>Total: <?php echo e($total); ?>৳</h3>
    </div>

    <div class="cart-actions">
        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Proceed to Checkout</a>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">Continue Shopping</a>
    </div>
    <?php else: ?>
    <p>Your cart is empty.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<style>
    .cart-page {
        padding: 20px;
    }

    .cart-table {
        width: 100%;
        border-collapse: collapse;
    }

    .cart-table th,
    .cart-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .cart-table img {
        max-width: 50px;
    }

    .cart-total {
        margin-top: 20px;
        font-size: 18px;
        font-weight: bold;
    }

    .cart-actions {
        margin-top: 20px;
    }

    .cart-actions .btn {
        padding: 10px 20px;
        margin-right: 10px;
    }
    .cart-table form {
    display: flex;
    gap: 5px;
    align-items: center;
}
.cart-table input[type="text"] {
    width: 40px;
    text-align: center;
    background: #f0f0f0;
}
.cart-table .btn-sm {
    padding: 5px 10px;
    font-size: 0.875rem;
}

</style>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-6th (4)\laravel-6th\resources\views/cart/index.blade.php ENDPATH**/ ?>