

<?php $__env->startSection('content'); ?>
<div class="container mt-5 d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="checkout-page card p-4 shadow-lg" style="width: 100%; max-width: 600px;">
        <h2 class="text-center mb-4">Checkout</h2>

        <?php if(count($cart) > 0): ?>
        <table class="cart-table table table-bordered">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e($item['quantity']); ?></td>
                    <td><?php echo e($item['price']); ?>৳</td>
                    <td><?php echo e($item['price'] * $item['quantity']); ?>৳</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h3 class="mt-3">Total: <?php echo e($total); ?>৳</h3>

        <form action="<?php echo e(route('checkout.submit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <!-- Customer details -->
            <div class="form-group">
                <label for="customer_name">Name:</label>
                <input type="text" name="customer_name" id="customer_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="customer_email">Email:</label>
                <input type="email" name="customer_email" id="customer_email" class="form-control" required>
            </div>

            <!-- Payment Option -->
            <div class="form-group mt-3">
                <label for="payment_method">Select Payment Method:</label>
                <select name="payment_method" id="payment_method" class="form-control" required>
                    <option value="Cash On Delivery">Cash On Delivery</option>
                    <option value="Online Payment">Online Payment</option>
                </select>
            </div>

            <!-- Online Payment Options -->
            <div id="online-payment-options" class="form-group mt-3" style="display: none;">
                <label>Choose Online Payment Option:</label>
                <div class="payment-button-group">
                    <button type="button" class="payment-button" data-method="bKash">bKash</button>
                    <button type="button" class="payment-button" data-method="Rocket">Rocket</button>
                    <button type="button" class="payment-button" data-method="Nagad">Nagad</button>
                    <button type="button" class="payment-button" onclick="window.location='<?php echo e(route('stripe.form')); ?>'" data-method="Card">Card</button>
                </div>
                <input type="hidden" name="online_payment_method" id="online_payment_method" required>
            </div>

            <!-- Proceed Button -->
            <div class="form-group text-center mt-4">
                <button type="submit" class="btn btn-success w-100">Proceed</button>
            </div>

        </form>

        <?php else: ?>
        <p class="text-center">Your cart is empty.</p>
        <?php endif; ?>
    </div>
</div>

<script>
    // Show online payment options
    document.getElementById('payment_method').addEventListener('change', function() {
        const method = this.value;
        const options = document.getElementById('online-payment-options');
        options.style.display = (method === 'Online Payment') ? 'block' : 'none';
    });

    // Handle button clicks
    document.querySelectorAll('.payment-button').forEach(function(button) {
        button.addEventListener('click', function() {
            // Remove 'active' from all
            document.querySelectorAll('.payment-button').forEach(btn => btn.classList.remove('active'));
            // Add 'active' to clicked one
            this.classList.add('active');
            // Set hidden input
            document.getElementById('online_payment_method').value = this.dataset.method;
        });
    });
</script>

<?php $__env->stopSection(); ?>

<style>
    .checkout-page {
        width: 100%;
        max-width: 600px;
    }

    .payment-button-group {
        display: flex;
        gap: 15px;
        margin-top: 10px;
    }

    .payment-button {
        padding: 10px 20px;
        border: 2px solid #ccc;
        background-color: #f8f9fa;
        cursor: pointer;
        border-radius: 5px;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .payment-button:hover {
        background-color: #e2e6ea;
    }

    .payment-button.active {
        background-color: #28a745;
        color: white;
        border-color: #28a745;
    }

    .container {
        min-height: 80vh;
    }

    /* Button Styling */
    .btn-success {
        font-size: 16px;
        font-weight: bold;
        padding: 10px;
    }
</style>

<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-6th (4)\laravel-6th\resources\views/checkout/index.blade.php ENDPATH**/ ?>