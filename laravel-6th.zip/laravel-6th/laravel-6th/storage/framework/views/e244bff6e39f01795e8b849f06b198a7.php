

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Product</h2>
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.product_update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="P_id">Product ID</label>
            <input type="text" name="P_id" class="form-control" value="<?php echo e(old('P_id', $product->P_id)); ?>" required>
        </div>

        <div class="form-group">
            <label for="P_name">Product Name</label>
            <input type="text" class="form-control" id="P_name" name="P_name" value="<?php echo e(old('P_name', $product->P_name)); ?>" required>
        </div>

        <div class="form-group">
            <label for="Description">Description</label>
            <textarea class="form-control" id="Description" name="Description" required><?php echo e(old('Description', $product->Description)); ?></textarea>
        </div>

        <div class="form-group">
            <label for="Price">Price</label>
            <input type="text" class="form-control" id="Price" name="Price" value="<?php echo e(old('Price', $product->Price)); ?>" required>
        </div>

        <div class="form-group">
            <label for="P_brand">Brand</label>
            <input type="text" class="form-control" id="P_brand" name="P_brand" value="<?php echo e(old('P_brand', $product->P_brand)); ?>" required>
        </div>

        <div class="form-group">
            <label for="Category">Category</label>
            <input type="text" class="form-control" id="Category" name="Category" value="<?php echo e(old('Category', $product->Category)); ?>" required>
        </div>

        <div class="form-group">
            <label for="P_img">Product Image</label>
            <input type="file" class="form-control-file" id="P_img" name="P_img">
            <?php if($product->P_img): ?>
                <img src="<?php echo e(asset('product_images/' . $product->P_img)); ?>" alt="Product Image" class="mt-2" style="width: 100px;">
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-6th (4)\laravel-6th\resources\views/admin/edit.blade.php ENDPATH**/ ?>