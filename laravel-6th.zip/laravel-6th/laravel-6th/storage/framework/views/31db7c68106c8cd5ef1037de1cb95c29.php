<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smile Shop Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .navbar {
            background-color: rgb(8, 118, 27) !important;
            box-shadow: 0 4px 10px rgba(18, 147, 35, 0.66);
            height: 80px;
        }

        .navbar-brand {
            font-style: italic;
            font-weight: bold;
            color: white !important;
            padding-left: 60px;
        }

        .nav-link {
            font-size: 18px;
            font-weight: bolder;
            padding: 0.7vh 30px;
            border-radius: 10px;
            color: white !important;
        }

        .btn-logout {
            background-color: #dc3545;
            color: white;
            padding: 6px 15px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Smile Shop</a>
            <div class="collapse navbar-collapse justify-content-end">
                <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.show')); ?>">ProductList</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.product_upload.form')); ?>">Upload</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.orderlist')); ?>">OrderList</a></li>
                    <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-logout">Logout</button>
                        </form>
                    </li>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-6th (4)\laravel-6th\resources\views/admin/nav2.blade.php ENDPATH**/ ?>