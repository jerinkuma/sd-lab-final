

<?php $__env->startSection('content'); ?>
<style>
    body {
        margin: 0;
        padding: 0;
        background-color: #f0f2f5;
        font-family: Arial, sans-serif;
    }

    .product-table {
        width: 95%;
        margin: 5vh auto;
        background-color: #ffffff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 14px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #4CAF50;
        color: white;
    }

    .product-img {
        width: 100px;
        height: auto;
    }

    .action-btn {
        padding: 8px 15px;
        font-size: 14px;
        margin: 2px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .edit-btn {
        background-color: #007bff;
        color: white;
    }

    .delete-btn {
        background-color: #dc3545;
        color: white;
    }

    .success-message {
        text-align: center;
        color: green;
        font-weight: bold;
        margin-top: 15px;
    }
</style>

<?php if(session('success')): ?>
    <div class="success-message"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="product-table">
    <table>
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Brand</th>
                <th>Category</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->P_id); ?></td>
                <td><?php echo e($item->P_name); ?></td>
                <td><?php echo e($item->Description); ?></td>
                <td><?php echo e($item->Price); ?></td>
                <td><?php echo e($item->P_brand); ?></td>
                <td><?php echo e($item->Category); ?></td>
                <td>
                    <?php if($item->P_img): ?>
                        <img src="<?php echo e(asset('product_images/'.$item->P_img)); ?>" class="product-img" alt="Image">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.product_edit', $item->id)); ?>" class="action-btn edit-btn">Edit</a>
                    <form action="<?php echo e(route('admin.product_delete', $item->id)); ?>" method="POST" style="display:inline-block;">
                       <?php echo csrf_field(); ?>
                     <?php echo method_field('DELETE'); ?>
                   <button type="submit" class="btn btn-danger btn-sm"
                  onclick="return confirm('Are you sure you want to delete this product?');">
                    Delete
                   </button>
</form>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-6th (4)\laravel-6th\resources\views/admin/show.blade.php ENDPATH**/ ?>