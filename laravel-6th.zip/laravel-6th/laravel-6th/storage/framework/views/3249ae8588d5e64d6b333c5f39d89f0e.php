<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\laravel-6th\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>