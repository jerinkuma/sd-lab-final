<!-- resources/views/order/status.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="order-status">
        <h2>Order Status</h2>

        <p><strong>Order ID:</strong> {{ $order->id }}</p>
        <p><strong>Customer Name:</strong> {{ $order->customer_name }}</p>
        <p><strong>Email:</strong> {{ $order->customer_email }}</p>
        <p><strong>Payment Method:</strong> {{ $order->payment_method }}</p>
        <p><strong>Status:</strong> {{ $order->status }}</p>

        <h3>Ordered Products:</h3>
        <ul>
            <li>
                <strong>Product:</strong> {{ $order->product_name }} 
                <strong>Quantity:</strong> {{ $order->quantity }} 
                <strong>Total:</strong> {{ number_format($order->price * $order->quantity, 2) }} ৳
            </li>
        </ul>
    </div>
@endsection
