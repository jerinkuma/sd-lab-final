<footer class="footer-distributed">
    <div class="footer-left">
        <h3>Smile Shop</h3>
        <p class="footer-links">
            <a href="{{ route('home') }}">Home</a>
            <a href="{{ route('faq') }}">Faq</a>
        </p>
    </div>
</footer>
