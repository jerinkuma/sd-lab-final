@extends('partials.navbar')

@section('content')
<div class="container mt-5 d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="card p-4 shadow-lg" style="width: 100%; max-width: 500px;">
        <h2 class="text-center mb-4">Card Payment</h2>

        @if (session('success'))
        <div class="alert alert-success mt-3">
            {{ session('success') }}
        </div>
        @endif

        <form action="{{ route('stripe.submit') }}" method="POST" id="payment-form">
            @csrf

            <div class="form-group">
                <label for="card-holder-name">Cardholder Name</label>
                <input type="text" id="card-holder-name" class="form-control" required placeholder="Enter your name">
            </div>

            <div class="form-group mt-3">
                <label for="amount">Amount</label>
                <input type="text" id="amount" name="amount" class="form-control" placeholder="Enter amount" required>
            </div>

            <div class="form-group mt-3">
                <label>Card Details</label>
                <div id="card-element" class="form-control p-2"></div>
                <div id="card-errors" class="text-danger mt-2"></div>
            </div>

            <button id="card-button" class="btn btn-primary mt-4 w-100" type="submit">
                Make Payment
            </button>
        </form>
    </div>
</div>

<!-- Stripe JS -->
<script src="https://js.stripe.com/v3/"></script>
<script>
    const stripe = Stripe('{{ env('STRIPE_KEY') }}');
    const elements = stripe.elements();
    const cardElement = elements.create('card');
    cardElement.mount('#card-element');

    cardElement.on('change', function(event) {
        const errorDiv = document.getElementById('card-errors');
        if (event.error) {
            errorDiv.textContent = event.error.message;
        } else {
            errorDiv.textContent = '';
        }
    });

    const form = document.getElementById('payment-form');

    form.addEventListener('submit', async function(event) {
        event.preventDefault();

        const { token, error } = await stripe.createToken(cardElement);

        if (error) {
            document.getElementById('card-errors').textContent = error.message;
        } else {
            const hiddenInput = document.createElement('input');
            hiddenInput.setAttribute('type', 'hidden');
            hiddenInput.setAttribute('name', 'stripeToken');
            hiddenInput.setAttribute('value', token.id);
            form.appendChild(hiddenInput);

            form.submit();
        }
    });
</script>
@endsection
