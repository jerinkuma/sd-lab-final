@extends('admin.nav2')

@section('content')
<style>
    body {
        margin: 0;
        padding: 0;
        background-color: #f0f2f5;
        font-family: Arial, sans-serif;
    }

    .product-table {
        width: 95%;
        margin: 5vh auto;
        background-color: #ffffff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 14px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }

    th {
        background-color: #4CAF50;
        color: white;
    }

    .product-img {
        width: 100px;
        height: auto;
    }

    .action-btn {
        padding: 8px 15px;
        font-size: 14px;
        margin: 2px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .edit-btn {
        background-color: #007bff;
        color: white;
    }

    .delete-btn {
        background-color: #dc3545;
        color: white;
    }

    .success-message {
        text-align: center;
        color: green;
        font-weight: bold;
        margin-top: 15px;
    }
</style>

@if(session('success'))
    <div class="success-message">{{ session('success') }}</div>
@endif

<div class="product-table">
    <table>
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Brand</th>
                <th>Category</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($products as $item)
            <tr>
                <td>{{ $item->P_id }}</td>
                <td>{{ $item->P_name }}</td>
                <td>{{ $item->Description }}</td>
                <td>{{ $item->Price }}</td>
                <td>{{ $item->P_brand }}</td>
                <td>{{ $item->Category }}</td>
                <td>
                    @if($item->P_img)
                        <img src="{{ asset('product_images/'.$item->P_img) }}" class="product-img" alt="Image">
                    @else
                        No Image
                    @endif
                </td>
                <td>
                    <a href="{{ route('admin.product_edit', $item->id) }}" class="action-btn edit-btn">Edit</a>
                    <form action="{{ route('admin.product_delete', $item->id) }}" method="POST" style="display:inline-block;">
                       @csrf
                     @method('DELETE')
                   <button type="submit" class="btn btn-danger btn-sm"
                  onclick="return confirm('Are you sure you want to delete this product?');">
                    Delete
                   </button>
</form>

                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
