<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Record</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://kit.fontawesome.com/06d164d474.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>

    <style>
        body {
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .container {
            margin-top: 20px;
        }

        .customer-card {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .customer-card:hover {
            transform: scale(1.05);
        }

        .customer-card h5 {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .customer-card p {
            font-size: 14px;
            color: #555;
        }

        .delete-btn {
            border: none;
            background: transparent;
            font-size: 18px;
            color: red;
            cursor: pointer;
        }

        .delete-btn:hover {
            color: darkred;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    @include('admin.nav2')

    <div class="container">
        <h1 class="text-center mb-4">Customer Record</h1>

        <!-- Success message -->
        @if(session('success'))
            <div class="alert alert-success text-center">{{ session('success') }}</div>
        @endif

        <!-- Customer Grid -->
        <div class="row">
            @forelse ($customers as $customer)
                <div class="col-md-4 mb-4">
                    <div class="customer-card p-3">
                        <h5>{{ $customer->username }}</h5>
                        <p>Email: {{ $customer->email }}</p>
                        <p>Mobile: {{ $customer->phone }}</p>
                        <p>Address: {{ $customer->address }}</p>
                        <form method="POST" action="{{ route('admin.customer.delete', $customer->id) }}">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="delete-btn">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center">
                    <p>No customers found</p>
                </div>
            @endforelse
        </div>
    </div>

    

</body>

</html>
