@extends('admin.nav2')

@section('content')
<div class="container">
    <h2>Edit Product</h2>
    
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('admin.product_update', $product->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="P_id">Product ID</label>
            <input type="text" name="P_id" class="form-control" value="{{ old('P_id', $product->P_id) }}" required>
        </div>

        <div class="form-group">
            <label for="P_name">Product Name</label>
            <input type="text" class="form-control" id="P_name" name="P_name" value="{{ old('P_name', $product->P_name) }}" required>
        </div>

        <div class="form-group">
            <label for="Description">Description</label>
            <textarea class="form-control" id="Description" name="Description" required>{{ old('Description', $product->Description) }}</textarea>
        </div>

        <div class="form-group">
            <label for="Price">Price</label>
            <input type="text" class="form-control" id="Price" name="Price" value="{{ old('Price', $product->Price) }}" required>
        </div>

        <div class="form-group">
            <label for="P_brand">Brand</label>
            <input type="text" class="form-control" id="P_brand" name="P_brand" value="{{ old('P_brand', $product->P_brand) }}" required>
        </div>

        <div class="form-group">
            <label for="Category">Category</label>
            <input type="text" class="form-control" id="Category" name="Category" value="{{ old('Category', $product->Category) }}" required>
        </div>

        <div class="form-group">
            <label for="P_img">Product Image</label>
            <input type="file" class="form-control-file" id="P_img" name="P_img">
            @if ($product->P_img)
                <img src="{{ asset('product_images/' . $product->P_img) }}" alt="Product Image" class="mt-2" style="width: 100px;">
            @endif
        </div>

        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>
</div>
@endsection
