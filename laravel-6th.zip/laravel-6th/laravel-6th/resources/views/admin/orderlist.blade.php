@extends('admin.nav2')

@section('content')
<style>
    body { background-color: #f0f2f5; font-family: Arial, sans-serif; }
    .order-table { width: 95%; margin: 5vh auto; background: #fff; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 14px; text-align: center; border-bottom: 1px solid #ddd; }
    th { background-color: #4CAF50; color: white; }
    .btn-action { padding: 6px 12px; border: none; border-radius: 5px; cursor: pointer; color: white; }
    .btn-approve { background-color: #28a745; }
    .btn-delete { background-color: #dc3545; }
</style>

@if(session('success'))
    <div class="text-center text-success fw-bold mt-3">{{ session('success') }}</div>
@endif

<div class="order-table">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Status</th>
                <th>Actions</th>
            

        </thead>
        <tbody>
            @foreach ($orders as $order)
            <tr>
                <td>{{ $order->id }}</td>
                <td>{{ $order->customer_name }}</td>
                <td>{{ $order->product_name }}</td>
                <td>{{ $order->quantity }}</td>
                <td>{{ $order->price }}</td>
                <td>{{ $order->status }}</td>
                <td>
                <form action="{{ route('orderlist.approve', $order->id) }}" method="POST" style="display:inline-block;">
                        @csrf
                        @method('PUT')
                        <button type="submit" class="btn btn-success btn-sm">Approve</button>
                    </form>

                    <form action="{{ route('orderlist.delete', $order->id) }}" method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
