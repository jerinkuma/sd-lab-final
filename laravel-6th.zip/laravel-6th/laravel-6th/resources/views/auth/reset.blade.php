@extends('auth.layouts')

@section('content')

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    html, body {
        overflow: hidden; /* Hide both horizontal and vertical scrollbars */
        height: 100vh; /* Ensures full viewport height */
        background-color: white;
        margin: 0;
        padding: 0;
    }

    .main {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        width: 100%;
    }


    .box {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 450px;
        padding: 20px;
        backdrop-filter: blur(10px);
        box-shadow: 0 0 30px rgb(0, 0, 0);
        border-radius: 10px;
        text-align: center;
    }

    .box h1 {
        margin-bottom: 15px;
    }

    .input {
        text-align: center;
        background-color: transparent;
        border-radius: 10px;
        margin-top: 10px;
        border: 1px solid;
        width: 80%;
        height: 40px;
        padding: 5px;
    }

    ::-webkit-input-placeholder {
        text-align: center;
        color: rgb(0, 0, 0);
    }

    .submit {
        width: 80%;
        height: 40px;
        border: none;
        margin: 15px 0;
        border-radius: 10px;
        background-color: rgba(0, 0, 0, 0.658);
        color: rgba(255, 255, 255, 0.737);
        cursor: pointer;
    }

    .submit:hover {
        background-color: rgba(246, 241, 241, 0.305);
        color: rgb(0, 0, 0);
        box-shadow: 0 0 30px rgb(0, 0, 0);
    }

    .box p {
        margin-bottom: 6px;
    }

    .box a {
        color: black;
        text-decoration: none;
        font-weight: 600;
        display: inline-block;
        padding: 5px 10px;
        transition: none;
    }

    .box a:hover {
        font-weight: 600;
        font-size: 21px;
        transform: none;
    }

    .error {
        color: red;
        text-align: center;
        margin-top: 10px;
    }
</style>

<div class="main">
    <div class="box">
        <h1>Reset Password</h1>

        @if (session('status'))
            <div class="alert alert-success">
                {{ session('status') }}
            </div>
        @endif

        <form action="{{ route('password.update') }}" method="POST">
            @csrf
            <input type="hidden" name="token" value="{{ $token }}">
            
            <input type="email" class="input" name="email" value="{{ old('email') }}" placeholder="Enter your email" required>

            <input type="password" class="input" name="password" placeholder="New Password" required>

            <input type="password" class="input" name="password_confirmation" placeholder="Confirm New Password" required>

            <input type="submit" class="submit" value="Reset Password">
        </form>

        <p>Remembered your password? <a href="{{ route('login') }}">Login</a></p>
    </div>
</div>

@endsection
