@extends('partials.navbar')

@section('content')
@if(session('success'))
    <div id="flash-message" class="alert-box">
        {{ session('success') }}
    </div>
@endif

<div class="home">
    @if ($products->isEmpty())
        <p>No products found in this category.</p>
    @else
        @foreach ($products as $product)
        <div class="wrapper">
            <div class="container">
                <form action="{{ route('cart.add') }}" method="POST">
                    @csrf
                    <div class="top">
                        <img src="{{ asset('product_images/'.$product->P_img) }}" alt="{{ $product->P_name }}">
                    </div>
                    <input type="hidden" name="product_image" value="{{ $product->P_img }}">
                    <div class="bottom">
                        <div class="left">
                            <div class="details">
                                <h4>{{ $product->P_name }}</h4>
                                <input type="hidden" name="product_name" value="{{ $product->P_name }}">
                                <input type="hidden" name="pid" value="{{ $product->P_id }}">
                                <p>{{ $product->Price }}৳</p>
                                <input type="hidden" name="product_price" value="{{ $product->Price }}">
                            </div>
                            <div class="buy">
                                <button type="submit" name="submit" value="{{ $product->P_id }}" class="btn btn-cart">
                                    <i class="fa-solid fa-cart-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        @endforeach
    @endif
</div>

@endsection

<script>
    document.addEventListener('DOMContentLoaded', function () {
        setTimeout(function () {
            const msg = document.getElementById('flash-message');
            if (msg) {
                msg.style.opacity = '0';
                setTimeout(() => msg.remove(), 500); // Remove after fade-out
            }
        }, 3000);
    });
</script>

<style>
    * {
        margin: 0;
        padding: 0;
    }

    html {
        scroll-behavior: smooth;
    }

    body {
        background-color: rgb(255, 255, 255);
        font-family: Times New Roman, serif;
        height: auto;
        overflow-y: auto;

    }

    .home {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        padding-top: 3vh;
        padding-bottom: 5vh;
        width: 100%;
        color: #000000;




    }

    .wrapper {
        width: 330px;
        height: 420px;
        display: flex;
        background: rgba(180, 220, 152, 0.89);
        margin: 10px auto;
        /* Centers and adds margin around the wrapper */
        position: relative;
        overflow: hidden;
        border-radius: 10px 10px 10px 10px;
        box-shadow: 0;
        transform: scale(0.95);
        transition: box-shadow 0.5s, transform 0.5s;
        left: -30px;
        /* Moves the wrapper 20px from the left */
        right: 10px
    }



    .wrapper:hover {
        transform: scale(1);
        box-shadow: 5px 20px 30px rgba(0, 0, 0, 0.2);
    }

    .wrapper .inside {
        z-index: 9;
        background: #8a878d;
        width: 140px;
        height: 140px;
        position: absolute;
        top: -70px;
        right: -70px;
        border-radius: 0px 0px 200px 200px;
        transition: all 0.7s, border-radius 2s, top 1s;
       
    }

    .wrapper .inside .icon {
        position: absolute;
        right: 85px;
        top: 85px;
        color: rgb(212, 202, 202);
        opacity: 1;
    }

    .wrapper .inside:hover {
        width: 100%;
        right: 0;
        top: 0;
        border-radius: 0;
        height: 80%;
        border-bottom: 1px solid;
        border-color: #ffffff;
    }

    .wrapper .inside:hover .icon {
        opacity: 0;
        right: 15px;
        top: 15px;
    }

    .wrapper .inside:hover .contents {
        opacity: 1;
        transform: scale(1);
        transform: translateY(0);
    }

    .wrapper .inside .contents {
        text-align: center;
        font-size: 22px;
        line-height: 5vh;
        padding: 5%;
        opacity: 0;
        transform: scale(0.5);
        transform: translateY(-200%);
        transition: opacity 0.2s, transform 0.8s;
    }

    .wrapper .container {
        width: 100%;
        height: 100%;
    }

    .wrapper img {
        height: 100%;
        width: 100%;
    }

    .wrapper .container .top {
        height: 80%;
        width: 100%;
    }

    .wrapper .container .bottom {
        width: 200%;
        height: 20%;
        transition: transform 0.5s;
    }

    .wrapper .container .bottom.clicked {
        transform: translateX(-50%);
    }

    .wrapper .container .bottom .left {
        height: 100%;
        width: 50%;
        background: #8a878d;
        position: relative;
        float: left;

    }

    .wrapper .container .bottom .left .details {
        font-size: 20px;
        padding: 15px;
        float: left;
        width: calc(70% - 40px);
    }

    .wrapper .container .bottom .left .details h4 {
        font-size: 18px;
        /* Adjust product name font size */
    }

    .wrapper .container .bottom .left p {
        font-size: 18px;
        /* Adjust price font size */
    }


    .wrapper .container .bottom .left .buy {
        float: right;
        width: calc(30% - 2px);
        height: 100%;
        background-color: #8a878d;
        transition: 0.5s;
        border-left: 1px solid;
        border-color: #ffffff;
    }

    .buy button {
        background-color: #8a878d;
        border: none;
        width: 100%;
        color: black;
        padding: 30px;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .buy button:hover {
        background: #666666;
    }

    .wrapper .container .bottom .left .buy i {
        font-size: 20px;
        margin-right: 10px;
    }

    .wrapper .container .bottom .right {
        width: 50%;
        background: #8a878d;
        color: black;
        float: right;
        height: 200%;
        overflow: hidden;
        font-size: 20px;
    }

    .wrapper .container .bottom .right .details {
        padding: 25px;
    }

    /* Style for the scroll-to-top button */
    .scroll-to-top-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 50%;
        padding: 15px;
        font-size: 18px;
        display: none;
        /* Initially hidden */
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .scroll-to-top-btn:hover {
        background-color: #45a049;
    }

    .scroll-to-top-btn i {
        font-size: 20px;
    }
    .cart-count {
    background-color: red;
    color: white;
    padding: 5px 8px;
    border-radius: 50%;
    font-size: 14px;
    position: absolute;
    top: -5px;
    right: -5px;
}

.alert-box {
        position: fixed;
        top: 30px;
        right: 20px;
        background-color: #d4edda;
        color: #155724;
        padding: 12px 20px;
        border-radius: 5px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        z-index: 9999;
        opacity: 1;
        transition: opacity 0.5s ease;
    }
</style>



    
