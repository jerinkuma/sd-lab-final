@extends('auth.layouts')

@section('content')

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    html, body {
        overflow: hidden; /* Hide both horizontal and vertical scrollbars */
        height: 100vh; /* Ensures full viewport height */
        background-color: white;
        margin: 0;
        padding: 0;
    }

    .main {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        width: 100%;
    }

    .box {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 450px;
        padding: 20px;
        backdrop-filter: blur(10px);
        box-shadow: 0 0 30px rgb(0, 0, 0);
        border-radius: 10px;
        text-align: center;
    }

    .box h1 {
        margin-bottom: 15px;
    }

    .input {
        text-align: center;
        background-color: transparent;
        border-radius: 10px;
        margin-top: 10px;
        border: 1px solid;
        width: 80%;
        height: 40px;
        padding: 5px;
    }

    ::-webkit-input-placeholder {
        text-align: center;
        color: rgb(0, 0, 0);
    }

    .submit {
        width: 80%;
        height: 40px;
        border: none;
        margin: 15px 0;
        border-radius: 10px;
        background-color: rgba(0, 0, 0, 0.658);
        color: rgba(255, 255, 255, 0.737);
        cursor: pointer;
    }

    .submit:hover {
        background-color: rgba(27, 156, 12, 0.6);
        color: rgb(0, 0, 0);
        box-shadow: 0 0 30px rgb(0, 0, 0);
    }

    .box p {
        margin-bottom: 6px;
    }

    .box a {
        color: black;
        text-decoration: none;
        font-weight: 600;
        display: inline-block;
        /* Ensures the anchor behaves like a block element without causing size changes */
        padding: 5px 10px;
        /* Adds some padding to the link to maintain consistency */
        transition: none;
        /* Smooth transition for any hover effect */

    }

    .box a:hover {
        font-weight: 600;
        font-size: 21px;
        transform: none;
        /* Prevents the link from scaling on hover */
    }

    .error {
        color: red;
        text-align: center;
        margin-top: 10px;
    }
</style>

<div class="main">
    <div class="box">
        <h1>Login Form</h1>

        @if ($message = Session::get('success'))
        <div class="alert alert-success text-center">
            {{ $message }}
        </div>
        @endif

        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        <form action="{{ route('authenticate') }}" method="post">
            @csrf
            <input type="email" class="input @error('email') is-invalid @enderror" id="email" name="email" placeholder="Email Address" value="{{ old('email') }}">
            @error('email')
            <div class="text-danger">{{ $message }}</div>
            @enderror

            <input type="password" class="input @error('password') is-invalid @enderror" id="password" name="password" placeholder="Password">
            @error('password')
            <div class="text-danger">{{ $message }}</div>
            @enderror

            <input type="submit" class="submit" value="Login">

            <p><a href="{{ route('password.request') }}">Forgot Password?</a></p>
            <p>Don't have an account? <a href="{{ route('register') }}">SignUp</a></p>
        </form>
    </div>
</div>

@endsection