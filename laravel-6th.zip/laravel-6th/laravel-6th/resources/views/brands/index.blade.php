@extends('partials.navbar')

@section('content')
<style>
    .brand-table-container {
        background: #ffffff;
        border-radius: 20px;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        padding: 30px;
        margin-top: 60px;
        max-width: 90%; /* Adjust the width to be smaller */
        margin-left: auto; /* Center the container */
        margin-right: auto; /* Center the container */
    }

    .brand-title {
        font-weight: 700;
        font-size: 2rem;
        color: #0a5f2e;
        margin-bottom: 25px;
    }

    .table thead th {
        background-color: rgb(105, 177, 144) !important;
        color: white;
        font-size: 1.1rem;
        text-align: center;
    }

    .table tbody td {
        vertical-align: middle;
        text-align: center;
        font-size: 1rem;
    }

    .table tbody tr:hover {
        background-color: #e7f8ef;
    }

    .btn-follow {
        background-color: rgb(63, 125, 96);
        color: white;
        border-radius: 8px;
        padding: 5px 15px;
        border: none;
    }

    .btn-follow:hover {
        background-color: #146c43;
    }
</style>


<div class="container">
    <div class="brand-table-container">
        <h2 class="text-center brand-title">Available Brands</h2>

        {{-- Success message --}}
        @if(session('success'))
            <div class="alert alert-success text-center">
                {{ session('success') }}
            </div>
        @endif

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Brand Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($brands as $index => $brand)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ $brand->P_brand }}</td>
                        <td>
                            <form method="POST" action="{{ route('brand.follow') }}">
                                @csrf
                                <input type="hidden" name="brand_name" value="{{ $brand->P_brand }}">
                                <button type="submit" class="btn btn-follow">Follow</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
