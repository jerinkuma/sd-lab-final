<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Smile Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <!-- FontAwesome CDN (if not already included) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        .navbar {
            background-color: rgb(8, 118, 27) !important;
            box-shadow: 0 4px 10px rgba(18, 147, 35, 0.66);
            height: 100px;
            padding: 15px 20px;
        }

        .navbar-brand {
            font-style: italic;
            font-weight: bold;
            color: white !important;

        }

        .nav-link {
            color: white !important;
        }

        .nav-link.active {
            font-weight: bold;
            text-decoration: underline;
        }

        .search-form {
            flex-grow: 1;
            margin-left: 800px;
            margin-right: 60px;
        }

        .search-form input {
            width: 50%;
        }

        .btn-logout {
            background: none;
            border: none;
            color: white;
            padding: 0;
            font: inherit;
            cursor: pointer;
            outline: inherit;
        }

        .dropdown-menu {
            min-width: 200px;
        }

        .dropdown-item:hover {
            background-color: #28a745;
            color: white;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Smile Shop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">



                <!-- Search Form -->
                <form class="d-flex flex-grow-1 mx-3" method="GET" action="<?php echo e(route('search')); ?>">
                    <input class="form-control me-2" type="search" placeholder="Search Product" aria-label="Search" name="query">
                    <button class="btn btn-outline-light" type="submit">Search</button>
                </form>
                


                <!-- Navigation Links -->
                <ul class="navbar-nav ms-auto">
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    </li>
                    <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link position-relative" href="<?php echo e(route('cart.index')); ?>">
                            <i class="fa-solid fa-cart-shopping"></i>
                            <?php
                            $cartCount = session('cart') ? count(session('cart')) : 0;
                            ?>
                            <?php if($cartCount > 0): ?>
                            <span class="cart-count"><?php echo e($cartCount); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>


                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('profile.show')); ?>">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('help')); ?>">Help & Support</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('brands')); ?>">Brands</a>

                    </li>
                    <!-- Category Dropdown -->
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="categoryDropdown" role="button" data-bs-toggle="dropdown">
                                Categories
                            </a>
                            <!-- In your navbar dropdown -->
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route('categories', ['category' => 'beauty care'])); ?>">Beauty care</a></li>

                                <li><a class="dropdown-item" href="<?php echo e(route('categories', ['category' => 'electronics'])); ?>">Electronics</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('categories', ['category' => 'books'])); ?>">Books</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('categories', ['category' => 'clothes'])); ?>">Clothes</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('categories', ['category' => 'groceries'])); ?>">Groceries</a></li>
                            </ul>

                        </li>
                    </ul>
                    <li class="nav-item">
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">Logout</button>
                        </form>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
        <div class="row justify-content-center text-center mt-3">
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel-6th\resources\views/partials/navbar.blade.php ENDPATH**/ ?>