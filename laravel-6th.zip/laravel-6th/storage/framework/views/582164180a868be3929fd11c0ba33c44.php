

<?php $__env->startSection('content'); ?>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    html, body {
        overflow: hidden; /* Hide both horizontal and vertical scrollbars */
        height: 100vh; /* Ensures full viewport height */
        background-color: white;
        margin: 0;
        padding: 0;
    }

    .main {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh; /* Ensure it takes full viewport height */
        padding: 0 50px; /* Adjust padding if needed */
    }

    .left-content {
        width: 100%;
        margin-right: 50px;
    }

    .left-content p {
        font-size: 40px;
        font-weight: bold;
        line-height: 1.6;
        color: rgb(0, 0, 0);
        padding-left: 50px; /* Reduce padding if necessary */
    }

    .highlight {
        font-style: italic;
        color: blueviolet;
    }

    .box {
        display: inline-block;
        text-align: center;
        width:800px; /* Reduced width to prevent overflow */
        height: auto; /* Allow it to adjust based on content */
        backdrop-filter: blur(10px);
        box-shadow: 0 0 30px rgb(0, 0, 0);
        border-radius: 10px;
        padding: 25px;
    }

    .box h1 {
        margin-bottom: 15px;
    }

    .input {
        text-align: center;
        background-color: transparent;
        border-radius: 10px;
        border: 1px solid;
        width: 65%;
        margin-top: 8px;
        height: 30px;
        padding: 5px;
    }

    .submit {
        width: 60%;
        height: 40px;
        border: none;
        margin: 15px 0 10px;
        border-radius: 10px;
        background-color: rgba(0, 0, 0, 0.658);
        color: rgba(255, 255, 255, 0.737);
        cursor: pointer;
    }

    .submit:hover {
        background-color: rgba(27, 156, 12, 0.6);
        color: rgb(0, 0, 0);
        box-shadow: 0 0 30px rgb(0, 0, 0);
    }

    .successful {
        color: green;
        text-align: center;
        margin-top: 10px;
    }

    .error {
        color: red;
        text-align: center;
        margin-top: 10px;
    }
</style>

<div class="main">
    <div class="left-content">
        <p>Welcome to our shop.</p>
        <p class="highlight"> 'Smile Shop' </p>
    </div>

    <div class="box">
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <h1>Sign Up Your Account</h1>

            <input type="text" placeholder="Username" name="username" class="input" value="<?php echo e(old('username')); ?>" required>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="email" placeholder="Email" name="email" class="input" value="<?php echo e(old('email')); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="number" placeholder="Phone Number" name="phone" class="input" value="<?php echo e(old('phone')); ?>" required>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="text" placeholder="Address" name="address" class="input" value="<?php echo e(old('address')); ?>" required>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="password" placeholder="New Password" name="password" class="input" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="password" placeholder="Confirm Password" name="password_confirmation" class="input" required>

            <button type="submit" class="submit">Submit</button>

            <p>Already have an account? <a href="<?php echo e(route('login')); ?>">Login</a></p>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-6th\resources\views/auth/register.blade.php ENDPATH**/ ?>