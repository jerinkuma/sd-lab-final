

<?php $__env->startSection('content'); ?>
<style>
    .profile-card {
        background: linear-gradient(145deg, #ffffff, #e6e6e6);
        border: none;
        border-radius: 20px;
        padding: 30px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        transition: transform 0.3s ease;
    }

    .profile-card:hover {
        transform: translateY(-5px);
    }

    .profile-title {
        font-size: 2rem;
        font-weight: bold;
        color: #17682d;
        margin-bottom: 25px;
    }

    .profile-info p {
        font-size: 1.1rem;
        margin-bottom: 15px;
        color: #333;
    }

    .profile-info strong {
        color: #17682d;
        width: 100px;
        display: inline-block;
    }

    body {
        background-color: #f4f8f5;
    }
</style>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card profile-card">
                <h2 class="text-center profile-title">Admin Profile</h2>
                <div class="profile-info">
                    <p><strong>Name:</strong> <?php echo e($admin->name); ?></p>
                    <p><strong>Email:</strong> <?php echo e($admin->email); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($admin->phone ?? 'N/A'); ?></p>
                    <p><strong>Address:</strong> <?php echo e($admin->address ?? 'N/A'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-6th\resources\views/admin/profile.blade.php ENDPATH**/ ?>