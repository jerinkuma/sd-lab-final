<footer class="footer-distributed">
    <div class="footer-left">
        <h3>Smile Shop</h3>
        <p class="footer-links">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <a href="<?php echo e(route('faq')); ?>">Faq</a>
        </p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\laravel-6th\resources\views/partials/footer.blade.php ENDPATH**/ ?>