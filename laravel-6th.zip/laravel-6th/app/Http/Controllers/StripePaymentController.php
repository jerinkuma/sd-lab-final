<?php

      

namespace App\Http\Controllers;

       

use Illuminate\Http\Request;

use Stripe;

use Illuminate\View\View;

use Illuminate\Http\RedirectResponse;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

       

class StripePaymentController extends Controller

{

    /**

     * success response method.

     *

     * @return \Illuminate\Http\Response

     */

    public function stripe(): View

    {

        return view('stripe');

    }

      

    /**

     * success response method.

     *

     * @return \Illuminate\Http\Response

     */

     public function stripePost(Request $request): RedirectResponse
     {
         // Validate request
         $request->validate([
             'stripeToken' => 'required',
             'amount' => 'required|numeric',
         ]);
     
         Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
     
         try {
             // 1. Charge the customer
             Stripe\Charge::create([
                 "amount" => $request->amount * 100, // amount in cents
                 "currency" => "usd",
                 "source" => $request->stripeToken,
                 "description" => "Order payment from Laravel shop",
             ]);
     
             // 2. Store Order
             $order = Order::create([
                 'customer_id' => Auth::id(), // assumes customer is logged in
                 'total_price' => $request->amount,
                 'status' => 'paid',
             ]);
     
             // 3. Store Order Items from session (or cart)
             $cart = Session::get('cart', []);
     
             foreach ($cart as $item) {
                 OrderItem::create([
                     'order_id' => $order->id,
                     'product_id' => $item['product_id'],
                     'quantity' => $item['quantity'],
                     'price' => $item['price'],
                 ]);
             }
     
             // 4. Clear the cart
             Session::forget('cart');
     
             return back()->with('success', 'Payment successful and order placed!');
         } catch (\Exception $e) {
             return back()->withErrors(['error' => $e->getMessage()]);
         }
     }
    

}