<?php

namespace App\Http\Controllers;
use App\Models\Order;


use Illuminate\Http\Request;

class CheckoutController extends Controller
{
    // Method to display the checkout page
    public function index()
{
    $cart = session('cart', []);
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    return view('checkout.index', compact('cart', 'total'));
}
// app/Http/Controllers/CheckoutController.php

// Handle order submission
public function submit(Request $request)
{
    $request->validate([
        'customer_name' => 'required|string|max:255',
        'customer_email' => 'required|email',
        'payment_method' => 'required|string',
    ]);

    $cart = session('cart', []);
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }

    // Create the order
    $order = Order::create([
        'customer_name' => $request->customer_name,
        'customer_email' => $request->customer_email,
        'payment_method' => $request->payment_method,
        'online_payment_method' => $request->payment_method === 'Online Payment' ? $request->online_payment_method : null,
        'total_amount' => $total,
    ]);

    // Clear the cart
    session()->forget('cart');

    // Redirect to status page
    return redirect()->route('order.status', $order->id);
}



}

