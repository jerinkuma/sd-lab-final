<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Amdin;

class OrderLineController extends Controller
{
    public function index()
{
    // Fetch orders and pass them to a view
    $orders = Order::all();  // Or use pagination if you want to handle large datasets
    return view('orderline.index', compact('orders'));
}

}
