<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;

use App\Models\Customer;

class AdminController extends Controller
{
    public function showLoginForm()
    {
        return view('admin.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);
        
        $admin = Admin::where('email', $request->email)->first();
        
        if ($admin && Hash::check($request->password, $admin->password)) {
            Auth::guard('admin')->login($admin);
            return redirect()->route('admin.dashboard');
        }

        return back()->withErrors(['username' => 'Invalid credentials.']);
    }

    public function dashboard()
    {
        $customers = Customer::all(); // Fetch all customers
        return view('admin.dashboard', compact('customers')); 
    }
    

    public function logout()
    {
        Auth::guard('admin')->logout(); // Ensure you're logging out from the admin guard
    
        
    
        return redirect()->route('login')->with('success', 'Logged out successfully!');
    
    }


    // Retrieve all customers
    public function customerList()
    {
        $customers = Customer::all(); // Fetch all customers from the 'customers' table
        return view('admin.dashboard', compact('customers'));
    }

    public function deleteCustomer($id)
{
    $customer = Customer::find($id);
    if ($customer) {
        $customer->delete();
        return redirect()->route('admin.dashboard')->with('success', 'Customer deleted successfully!');
    }
    return redirect()->route('admin.dashboard')->with('error', 'Customer not found.');
}


    
}

