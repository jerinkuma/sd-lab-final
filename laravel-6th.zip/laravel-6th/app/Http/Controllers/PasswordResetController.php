<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class PasswordResetController extends Controller
{
    // Show the password reset link request form
    public function showLinkRequestForm()
    {
        return view('auth.email');
    }

    // Send the password reset link to the user's email
    public function sendResetLinkEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:customers,email',  // Make sure this matches the customers table
        ]);

        $response = Password::broker('customers')->sendResetLink(
            $request->only('email')
        );

        return $response == Password::RESET_LINK_SENT
            ? back()->with('status', trans($response))
            : back()->withErrors(['email' => trans($response)]);
    }

    // Show the reset form
    public function showResetForm(Request $request, $token = null)
{
    return view('auth.reset')->with(
        ['token' => $token, 'email' => $request->email]
    );
}

public function reset(Request $request)
{
    $this->validate($request, [
        'email' => 'required|email',
        'password' => 'required|confirmed|min:8',
        'token' => 'required',
    ]);

    $response = Password::broker('customers')->reset(
        $request->only('email', 'password', 'password_confirmation', 'token'),
        function ($user, $password) {
            $user->password = bcrypt($password);
            $user->save();
        }
    );

    return $response == Password::PASSWORD_RESET
        ? redirect()->route('login')->with('status', trans($response))
        : back()->withErrors(['email' => trans($response)]);
}

    // Validation for email in password reset
    protected function validateEmail(Request $request)
    {
        $request->validate(['email' => 'required|email']);
    }

    // Validation for password reset
    protected function validatePasswordReset(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|confirmed|min:8',
            'token' => 'required',
        ]);
    }
}
