<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;



class OrderListController extends Controller
{
    public function index()
{
    $orders = Order::all(); // Or your logic to fetch orders

    return view('orderlist.index', compact('orders'));
}

    public function create()
    {
        return view('orderlist.create'); // Return a view for creating orders
    }

    public function store(Request $request)
    {
        // Logic for storing the order
    }
}

