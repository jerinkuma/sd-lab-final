<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BrandController extends Controller
{
    public function index()
{
    $brands = DB::table('products')->select('P_brand')->distinct()->get();

    return view('brands.index', compact('brands'));
}
public function follow(Request $request)
{
    $brandName = $request->input('brand_name');
    
    // You can add logic here to store the followed brand in a pivot table or user preference

    return back()->with('success', "You have followed the brand: $brandName");
}

}
