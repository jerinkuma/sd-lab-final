<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    // ProductController.php
public function showCategory($category)
{
    // Adjust this query to fetch products based on the category
    $products = Product::where('category', $category)->get();

    return view('auth.home', compact('products'));
}

public function search(Request $request)
{
    // Get the search query from the request
    $query = $request->input('query');

    // If query is not empty, perform the search
    if ($query) {
        // Search the product by name (assuming 'P_name' is the column for product name)
        $products = Product::where('P_name', 'like', '%' . $query . '%')->get();

        // Check if no products were found
        if ($products->isEmpty()) {
            // No products found, return a view with a message
            return view('search-results', compact('products'))->with('message', 'No products found.');
        }

        // Products found, return the results
        return view('search-results', compact('products'));
    }

    // If query is empty, redirect back with a message
    return redirect()->back()->with('message', 'Please enter a product name.');
}



}
