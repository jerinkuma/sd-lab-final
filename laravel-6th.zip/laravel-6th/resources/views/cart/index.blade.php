@extends('partials.navbar')

@section('content')
<div class="cart-page">
    <h2>Your Cart</h2>

    @if(count($cart) > 0)
    <table class="cart-table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach($cart as $id => $item)
            <tr>
                <td>
                    <img src="{{ asset('product_images/'.$item['image']) }}" alt="{{ $item['name'] }}" width="50">
                    {{ $item['name'] }}
                </td>
                <td>{{ number_format($item['price'], 2) }}৳</td>
                <td>
                    <form action="{{ route('cart.update', $id) }}" method="POST" style="display: flex; align-items: center;">
                        @csrf
                        @method('PUT')
                        <button type="submit" name="quantity" value="{{ $item['quantity'] - 1 }}" class="btn btn-sm btn-secondary" {{ $item['quantity'] <= 1 ? 'disabled' : '' }}>-</button>
                        <input type="text" value="{{ $item['quantity'] }}" readonly style="width: 40px; text-align: center; border: none;">
                        <button type="submit" name="quantity" value="{{ $item['quantity'] + 1 }}" class="btn btn-sm btn-secondary">+</button>
                    </form>
                </td>
                <td>{{ number_format($item['price'] * $item['quantity'], 2) }}৳</td>
                <td>
                    <form action="{{ route('cart.remove', $id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>

    </table>

    <div class="cart-total">
        <h3>Total: {{ $total }}৳</h3>
    </div>

    <div class="cart-actions">
        <a href="{{ route('checkout') }}" class="btn btn-primary">Proceed to Checkout</a>
        <a href="{{ route('home') }}" class="btn btn-secondary">Continue Shopping</a>
    </div>
    @else
    <p>Your cart is empty.</p>
    @endif
</div>
@endsection

<style>
    .cart-page {
        padding: 20px;
    }

    .cart-table {
        width: 100%;
        border-collapse: collapse;
    }

    .cart-table th,
    .cart-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .cart-table img {
        max-width: 50px;
    }

    .cart-total {
        margin-top: 20px;
        font-size: 18px;
        font-weight: bold;
    }

    .cart-actions {
        margin-top: 20px;
    }

    .cart-actions .btn {
        padding: 10px 20px;
        margin-right: 10px;
    }
    .cart-table form {
    display: flex;
    gap: 5px;
    align-items: center;
}
.cart-table input[type="text"] {
    width: 40px;
    text-align: center;
    background: #f0f0f0;
}
.cart-table .btn-sm {
    padding: 5px 10px;
    font-size: 0.875rem;
}

</style>