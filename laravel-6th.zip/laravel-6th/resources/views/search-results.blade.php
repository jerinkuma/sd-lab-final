@extends('partials.navbar')

@section('content')
@if(session('success'))
    <div id="flash-message" class="alert-box">
        {{ session('success') }}
    </div>
@endif

<div class="home">
    @if ($products->isEmpty())
        <p>No products found in this category.</p>
    @else
        @foreach ($products as $product)
        <div class="wrapper">
            <div class="container">
                <form action="{{ route('cart.add') }}" method="POST">
                    @csrf
                    <div class="top">
                        <img src="{{ asset('product_images/'.$product->P_img) }}" alt="{{ $product->P_name }}">
                    </div>
                    <input type="hidden" name="product_image" value="{{ $product->P_img }}">
                    <div class="bottom">
                        <div class="left">
                            <div class="details">
                                <h4>{{ $product->P_name }}</h4>
                                <input type="hidden" name="product_name" value="{{ $product->P_name }}">
                                <input type="hidden" name="pid" value="{{ $product->P_id }}">
                                <p>{{ $product->Price }}৳</p>
                                <input type="hidden" name="product_price" value="{{ $product->Price }}">
                            </div>
                            <div class="buy">
                                <button type="submit" name="submit" value="{{ $product->P_id }}" class="btn btn-cart">
                                    <i class="fa-solid fa-cart-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        @endforeach
    @endif
</div>

@endsection

<script>
    document.addEventListener('DOMContentLoaded', function () {
        setTimeout(function () {
            const msg = document.getElementById('flash-message');
            if (msg) {
                msg.style.opacity = '0';
                setTimeout(() => msg.remove(), 500); // Remove after fade-out
            }
        }, 3000);
    });
</script>

<style>
    * {
        margin: 0;
        padding: 0;
    }

    html {
        scroll-behavior: smooth;
    }

    body {
        background-color: rgb(255, 255, 255);
        font-family: Times New Roman, serif;
        height: auto;
        overflow-y: auto;
    }

    .home {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        padding-top: 3vh;
        padding-bottom: 5vh;
        width: 100%;
        color: #000000;
    }

    .wrapper {
        width: 330px;
        height: 420px;
        display: flex;
        background: rgba(180, 220, 152, 0.89);
        margin: 10px auto;
        position: relative;
        overflow: hidden;
        border-radius: 10px;
        box-shadow: 0;
        transform: scale(0.95);
        transition: box-shadow 0.5s, transform 0.5s;
        left: -30px;
    }

    .wrapper:hover {
        transform: scale(1);
        box-shadow: 5px 20px 30px rgba(0, 0, 0, 0.2);
    }

    .wrapper .container {
        width: 100%;
        height: 100%;
    }

    .wrapper img {
        height: 100%;
        width: 100%;
    }

    .wrapper .container .top {
        height: 80%;
        width: 100%;
    }

    .wrapper .container .bottom {
        width: 200%;
        height: 20%;
        transition: transform 0.5s;
    }

    .wrapper .container .bottom .left {
        height: 100%;
        width: 50%;
        background: #8a878d;
        position: relative;
        float: left;
    }

    .wrapper .container .bottom .left .details {
        font-size: 20px;
        padding: 15px;
        float: left;
        width: calc(70% - 40px);
    }

    .wrapper .container .bottom .left .details h4 {
        font-size: 18px;
    }

    .wrapper .container .bottom .left p {
        font-size: 18px;
    }

    .wrapper .container .bottom .left .buy {
        float: right;
        width: calc(30% - 2px);
        height: 100%;
        background-color: #8a878d;
        transition: 0.5s;
        border-left: 1px solid;
        border-color: #ffffff;
    }

    .buy button {
        background-color: #8a878d;
        border: none;
        width: 100%;
        color: black;
        padding: 30px;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .buy button:hover {
        background: #666666;
    }

    .wrapper .container .bottom .left .buy i {
        font-size: 20px;
        margin-right: 10px;
    }

    .alert-box {
        position: fixed;
        top: 30px;
        right: 20px;
        background-color: #d4edda;
        color: #155724;
        padding: 12px 20px;
        border-radius: 5px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        z-index: 9999;
        opacity: 1;
        transition: opacity 0.5s ease;
    }
</style>
