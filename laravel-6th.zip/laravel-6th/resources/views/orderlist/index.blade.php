<h1>Order List</h1>

@foreach ($orders as $order)
    <p>{{ $order->id }} - {{ $order->product_name }}</p>
@endforeach
