<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Support</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        html,
        body {
            overflow: hidden;
            /* Hide both horizontal and vertical scrollbars */
            height: 100vh;
            /* Ensures full viewport height */
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .main {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            width: 100%;
        }

        .left,
        .right {
            width: 47%;
            margin: auto;
        }

        .box {
            text-align: center;
            width: 100%;
            min-height: 250px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 30px rgb(0, 0, 0);
            border-radius: 10px;
            margin-top: 5 px;
            margin-bottom: 15vh;
        }

        .box h1 {
            padding-top: 30px;
        }

        .button-container {
            margin-top: 5vh;
        }

        .help-button {
            width: 300px;
            height: 50px;
            border: none;
            margin: 15px;
            border-radius: 10px;
            background-color: rgba(0, 0, 0, 0.658);
            color: rgb(8, 8, 8);
            font-size: 18px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            line-height: 50px;
        }

        .help-button:hover {
            background-color: rgba(246, 241, 241, 0.305);
            color: rgb(0, 0, 0);
            box-shadow: 0 4px 12px rgb(0, 0, 0);
        }

        .chat-button {
            background-color:rgb(159, 216, 218);
            /* WhatsApp green */
        }

        .chat-button:hover {
            background-color:rgb(49, 124, 115);
            /* Darker WhatsApp green */
        }

        .email-button {
            background-color:rgb(231, 153, 245);
            /* Email blue */
        }

        .email-button:hover {
            background-color:rgb(120, 95, 127);
            /* Darker blue */
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    @include('partials.navbar')

    <div class="main">
        <div class="left">
            <div class="box">
                <h1>Help & Support</h1>
                <div class="button-container">
                    <a href="https://chat.whatsapp.com/BF2pY3x0tHK1RcnBZ8ZERP" class="help-button chat-button" target="_blank">Chat with us</a>
                    <a href="https://mail.google.com/mail/u/0/?source=mailto&to=electricityboard1122@gmail.com&fs=1&tf=cm"" class=" help-button email-button">Contact with Email</a>
                </div>
            </div>
        </div>
    </div>


</body>

</html>