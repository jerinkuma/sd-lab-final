<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">


    <style>
        * {
            margin: 0;
            padding: 0;
        }

        html,
        body {
            overflow: hidden;
            /* Hide both horizontal and vertical scrollbars */
            height: 100vh;
            /* Ensures full viewport height */
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .main {
            display: flex;
            align-items: flex-start;
            /* Align to the top */
            justify-content: center;
            min-height: 100vh;
            width: 100%;
            padding-top: 75px;
            /* space from top */
        }

        .box {
            display: inline-block;
            text-align: center;
            width: 600px;
            height: 400px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 30px rgb(0, 0, 0);
            border-radius: 10px;
        }

        .box h1 {
            padding-top: 30px;
            margin-bottom: 15px;
        }

        .input {
            text-align: center;
            background-color: transparent;
            border-radius: 10px;
            border: 1px solid;
            width: 65%;
            margin-top: 8px;
            height: 30px;
        }

        .submit {
            width: 60%;
            height: 40px;
            border: none;
            margin: 15px 0 10px;
            border-radius: 10px;
            background-color: rgba(0, 0, 0, 0.658);
            color: rgba(255, 255, 255, 0.737);
        }

        .submit:hover {
            background-color: rgba(27, 156, 12, 0.6);
            color: rgb(0, 0, 0);
            box-shadow: 0 0 30px rgb(0, 0, 0);
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 10px;
        }
    </style>

</head>

<body>

    @include('partials.navbar')



    <div class="main">
        <div class="box">
            <form action="{{ route('profile.update') }}" method="post">
                @csrf
                <h1>Update Your Profile</h1>
                <input type="text" class="input" name="old_username" placeholder="Old Username" required>
                <input type="text" class="input" name="new_username" placeholder="New Username" required>
                @error('username')
                <div class="error">{{ $message }}</div>
                @enderror

                <input type="email" class="input" name="old_email" placeholder="Old Email" required>
                <input type="email" class="input" name="new_email" placeholder="New Email" required>
                @error('email')
                <div class="error">{{ $message }}</div>
                @enderror

                <input type="number" class="input" name="number" placeholder="Number" required>
                @error('phone')
                <div class="error">{{ $message }}</div>
                @enderror

                <input type="text" class="input" name="address" placeholder="Address" required>
                @error('address')
                <div class="error">{{ $message }}</div>
                @enderror

                <button type="submit" class="submit">Update</button>

            </form>
            @if(session('success'))
            <div class="error" style="color: green;">{{ session('success') }}</div>
            @endif

            @if($errors->any())
            <div class="error">{{ $errors->first() }}</div>
            @endif

        </div>
    </div>
</body>

</html>