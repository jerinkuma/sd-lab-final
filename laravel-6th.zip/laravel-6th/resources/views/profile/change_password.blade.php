<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        html,
        body {
            overflow: hidden;
            /* Hide both horizontal and vertical scrollbars */
            height: 100vh;
            /* Ensures full viewport height */
            background-color: white;
            margin: 0;
            padding: 0;
        }

        .main {
            display: flex;
            align-items: flex-start;
            /* Align to the top */
            justify-content: center;
            min-height: 100vh;
            width: 100%;
            padding-top: 90px;
            /* space from top */
        }

        .box {
            display: inline-block;
            text-align: center;
            width: 500px;
            height: 300px;
            backdrop-filter: blur(10px);
            box-shadow: 0 0 30px rgb(0, 0, 0);
            border-radius: 10px;
        }


        .input {
            width: 70%;
            height: 35px;
            margin-top: 10px;
            border: 1px solid;
            border-radius: 10px;
            text-align: center;
            background-color: transparent;
        }

        .submit {
            width: 70%;
            height: 40px;
            border: none;
            margin: 5% 0;
            border-radius: 10px;
            background-color: rgba(0, 0, 0, 0.658);
            color: rgba(255, 255, 255, 0.737);
            cursor: pointer;
        }

        .submit:hover {
            background-color: rgba(27, 156, 12, 0.6);
            color: rgb(0, 0, 0);
            box-shadow: 0 0 30px rgb(0, 0, 0);
        }

        .message {
            text-align: center;
            font-weight: bold;
            margin-top: 10px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>

    @include('partials.navbar')

    <div class="main">
        <div class="box">
            <h1>Change Your Password</h1>

            @if(session('success'))
            <p class="message success">{{ session('success') }}</p>
            @elseif(session('error'))
            <p class="message error">{{ session('error') }}</p>
            @endif

            <form action="{{ route('profile.updatePassword') }}" method="post">
                @csrf
                <input type="password" class="input" name="old_password" placeholder="Old Password" required>
                <input type="password" class="input" name="new_password" placeholder="New Password" required>
                <input type="password" class="input" name="new_password_confirmation" placeholder="Confirm Password" required>
                <button type="submit" class="submit">Change Password</button>
            </form>
        </div>
    </div>

    @include('partials.footer')

</body>

</html>