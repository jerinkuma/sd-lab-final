@extends('admin.nav2')

@section('content')
<style>
    body {
        margin: 0;
        padding: 0;
        background-color: #f0f2f5;
        font-family: Arial, sans-serif;
    }

    .upload-form {
        max-width: 600px;
        margin: 5vh auto;
        background-color: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
    }

    .upload-form h2 {
        text-align: center;
        margin-bottom: 25px;
        color: #333;
    }

    .upload-form input[type="text"],
    .upload-form input[type="number"],
    .upload-form input[type="file"],
    .upload-form textarea {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        background-color: #f9f9f9;
        font-size: 14px;
    }

    .upload-form textarea {
        resize: vertical;
    }

    .upload-form button {
        width: 100%;
        padding: 12px;
        background-color: #28a745;
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .upload-form button:hover {
        background-color: #218838;
    }

    .success-message {
        text-align: center;
        color: green;
        font-weight: bold;
        margin-bottom: 15px;
    }
</style>

<div class="upload-form">
    <h2>Upload Product</h2>

    @if(session('success'))
        <div class="success-message">{{ session('success') }}</div>
    @endif

    <form action="{{ route('admin.product_upload.submit') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <input type="text" name="P_id" placeholder="Product ID" required>
        <input type="text" name="P_name" placeholder="Product Name" required>
        <textarea name="Description" rows="4" placeholder="Product Description"></textarea>
        <input type="number" name="Price" placeholder="Price" required>
        <input type="text" name="P_brand" placeholder="Brand">
        <input type="text" name="Category" placeholder="Category">

        <input type="file" name="P_img">

        <button type="submit">Upload</button>
    </form>
</div>
@endsection
