<div class="explore" id="explore">
    <div class="left">
        <form id="catbar" method="post" action="{{ route('category') }}">
            @csrf
            <select class="drop" name="category" onchange="submitForm()">
                <option value="all">Category</option>
                @foreach($categories as $category)
                    <option value="{{ $category }}">{{ $category }}</option>
                @endforeach
            </select>
        </form>
    </div>
    <div class="right">
        <form method="post" action="{{ route('search') }}">
            @csrf
            <input type="text" placeholder="Search Product" name="str">
            <button type="submit" name="sub">
                <i class="fa fa-search"></i>
            </button>
        </form>
    </div>
</div>
<script>
    function submitForm() {
        document.getElementById("catbar").submit();
    }
</script>
